import sqlite3
connection = sqlite3.connect('company_DB.db')
cursor = connection.cursor()

cursor.execute('CREATE TABLE IF NOT EXISTS Sales (sales_id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,FOREIGN KEY (customer_id) REFERENCES Customer(customer_id))')
cursor.execute("INSERT INTO Sales (customer_id) VALUES (1), (2), (3),(4),(5),(6),(7),(8),(9),(10)")
# result = cursor.execute("select * from Sales").fetchall()
# print(result)

cursor.execute('CREATE TABLE IF NOT EXISTS Customer (customer_id INTEGER PRIMARY KEY,age INTEGER)')
cursor.execute("INSERT INTO Customer (customer_id, age) VALUES (1, 25), (2, 30), (3, 35),(4, 23),(5, 18),(6, 16),(7, 19),(8, 21),(9, 36),(10, 25),(11,21),(12,23),(13,19),(14,20)")
# result = cursor.execute("select * from Customer").fetchall()
# print(result)

cursor.execute('CREATE TABLE IF NOT EXISTS Items (item_id INTEGER PRIMARY KEY,item_name TEXT)')
cursor.execute("INSERT INTO Items (item_id, item_name) VALUES (1, 'X'), (2, 'Y'), (3, 'Z')")
# result = cursor.execute("select * from Items").fetchall()
# print(result)

cursor.execute('CREATE TABLE IF NOT EXISTS Orders (order_id INTEGER PRIMARY KEY,sales_id INTEGER,item_id INTEGER,quantity INTEGER,FOREIGN KEY (sales_id) REFERENCES Sales(sales_id),FOREIGN KEY (item_id) REFERENCES Items(item_id))')
cursor.execute("INSERT INTO Orders (sales_id, item_id, quantity) VALUES (1, 1, 10), (2, 1, 0), (2, 2, 1), (3, 3, 1), (4, 3, 1), (3, 3, 1),(5, 1, 10),(6, 1, 10),(7, 1, 10),(8, 1, 10),(8, 1, 10),(7, 1, 10),(9, 1, 10),(10, 1, 10),(10, 1, 10),(4, 1, 10),(6, 1, 10),(7, 1, 10),(5, 1, 10),(9, 1, 10)")
# result = cursor.execute("select * from Orders").fetchall()
# print(result)

connection.commit()
connection.close()

