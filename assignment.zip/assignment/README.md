# data processing
python script for given assignment folloed by PDF file

# change dir
cd ./assignment/

# install for required packages using pip
pip install -r requirements.txt 

# run the database_creation.py for create a database 
python3 database_creation.py

# run the pandas_py.py for pandas approach
python3 pandas_py.py 

# run the sql_py.py for sql approach
python3 sql_py.py 

